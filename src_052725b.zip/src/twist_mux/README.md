twist_mux
=========

Twist multiplexer with support for
[geometry_msgs/Twist](http://docs.ros.org/api/geometry_msgs/html/msg/Twist.html)
topics and
[std_msgs/Bool](http://docs.ros.org/api/std_msgs/html/msg/Bool.html) locks with priorities.

See [documentation](http://wiki.ros.org/twist_mux).